package com.kit.megaphone.datas;

public class ArticleData {
}
