package com.kit.megaphone.ui.activities;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.kit.megaphone.R;
import com.kit.megaphone.databinding.ActivitySignInBinding;
import com.kit.megaphone.utils.VerifyUtil;

public class SignInActivity extends AppCompatActivity {

    private ActivitySignInBinding binding;

    private FirebaseAuth auth;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_sign_in);
        binding.setActivity(this);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();
    }

    public void signIn(View view) {
        final String email = binding.email.getText().toString();
        final String password = binding.password.getText().toString();

        if (!VerifyUtil.verifyStrings(email, password)) {
            Toast.makeText(this, "입력칸 중 공백이 있습니다", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Toast.makeText(this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    startActivity(new Intent(this, MainActivity.class));
                    Toast.makeText(this, "로그인 완료됨", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    public void signUp(View view) {
        startActivity(new Intent(this, SignUpActivity.class));
    }

    public void findAccount(View view) {

    }
}
